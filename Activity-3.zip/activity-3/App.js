import React from 'react';
import {StyleSheet, Text, View, SectionList, StatusBar,} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const Separator = () => <View style={styles.separator} />;

const DATA = [
  {
    title: 'Morning',
    data: ['almusal', 'ligo', 'workout','jogging','cleaning my room'],
  },
  {
    title: 'Afternoon',
    data: ['cooking', 'eating', 'playing online games','tulog','go to gym'],
  },
  {
    title: 'Evening',
    data: ['wash my face', 'watching anime', 'playing mobile legends','puyat', 'eating midnight snack'],
  },
  

];

const App = () => (
  <SafeAreaProvider>
    <SafeAreaView style={styles.container} edges={['top']}>
      <SectionList
        sections={DATA}
        keyExtractor={(item, index) => item + index}
        renderItem={({item}) => (
          <View style={styles.item}>
            <Text style={styles.title}>{item}</Text>
          </View>
        )}
        renderSectionHeader={({section: {title}}) => (
          <Text style={styles.header}>{title}</Text>
        )}
      />
    </SafeAreaView>
  </SafeAreaProvider>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
    marginHorizontal: 16,
  },
  item: {
    backgroundColor: 'lightblue',
    padding: 20,
    marginVertical: 8,
  },
  header: {
    fontSize: 32,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
  },
});

export default App;